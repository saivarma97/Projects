CREATE DATABASE sql_course;

-- DROP DATABASE IF EXISTS sql_course;